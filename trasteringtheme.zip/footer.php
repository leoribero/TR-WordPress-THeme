
							<!-- Footer -->
								<footer id="footer">								</footer>
								

								  <script src="<?php bloginfo('template_url'); ?>/assets/js/script.js"></script>
								  
								  <!-- <script src="js/backup.js"></script> -->
								</body>
								
								</html>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<!--<script src="<?php bloginfo('template_url'); ?>/assets/js/script.js"></script>-->
			<!-- <script src="<?php bloginfo('template_url'); ?>/assets/js/jquery.min.js"></script> -->
			<!-- <script src="<?php bloginfo('template_url'); ?>/assets/js/browser.min.js"></script>
			<script src="<?php bloginfo('template_url'); ?>/assets/js/breakpoints.min.js"></script>
			<script src="<?php bloginfo('template_url'); ?>/assets/js/util.js"></script>
			<script src="<?php bloginfo('template_url'); ?>/assets/js/main.js"></script> -->
