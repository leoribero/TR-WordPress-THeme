<?php 
/* Template Name: home-page */
	
 ?>
 
 <script type="text/javascript">
 // 	// Simulate an HTTP redirect:
 window.location.replace("https://trastering.es");
 // 	
 // 	</script>
